# meeting_scheduler/views.py
from django.shortcuts import render
from .views_logic import process_input

def scheduler_view(request):
    if request.method == 'POST':
        input_text = request.POST.get('input_text', '')
        output = process_input(input_text)
        return render(request, 'meeting_scheduler/output.html', {'output': output})
    
    return render(request, 'meeting_scheduler/input.html')
