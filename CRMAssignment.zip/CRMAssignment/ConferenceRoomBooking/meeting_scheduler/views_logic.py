from datetime import datetime, timedelta


meeting_rooms = [
    {"name": "C-Contact", "capacity": 3},
    {"name": "S-Sharing", "capacity": 7},
    {"name": "T-Team", "capacity": 20}
]

buffer_times = [
    {"start": "09:00", "end": "09:15"},
    {"start": "13:15", "end": "13:45"},
    {"start": "18:45", "end": "19:00"}
]


booked_meetings = []

def is_valid_time_format(time_str):
    try:
        datetime.strptime(time_str, '%H:%M')
        return True
    except ValueError:
        return False

def is_buffer_time(start_time, end_time):
    for buffer_time in buffer_times:
        buffer_start = datetime.strptime(buffer_time["start"], '%H:%M').time()
        buffer_end = datetime.strptime(buffer_time["end"], '%H:%M').time()
        if buffer_start <= start_time < buffer_end or buffer_start < end_time <= buffer_end:
            return True
    return False

def is_valid_person_capacity(capacity):
    return 2 <= capacity <= 20

def get_available_rooms(start_time, end_time):
    available_rooms = []
    for room in meeting_rooms:
        if room["capacity"] >= booked_capacity(start_time, end_time):
            available_rooms.append(room["name"])
    return available_rooms

def booked_capacity(start_time, end_time):
    total_capacity = 0
    for meeting in booked_meetings:
        if meeting["start_time"] < end_time and meeting["end_time"] > start_time:
            total_capacity += meeting["capacity"]
    return total_capacity

def book_meeting_room(start_time, end_time, capacity):
    if not is_valid_person_capacity(capacity):
        return "NO_VACANT_ROOM"

    if is_buffer_time(start_time, end_time):
        return "NO_VACANT_ROOM"

    if end_time <= start_time:
        return "NO_VACANT_ROOM"

    available_rooms = get_available_rooms(start_time, end_time)
    if not available_rooms:
        return "NO_VACANT_ROOM"

    best_fit_room = None
    for room in meeting_rooms:
        if room["name"] in available_rooms:
            if room["capacity"] >= capacity and (best_fit_room is None or room["capacity"] < best_fit_room["capacity"]):
                best_fit_room = room

    if best_fit_room:
        booked_meetings.append({
            "start_time": start_time,
            "end_time": end_time,
            "capacity": capacity
        })
        return best_fit_room["name"]

    return "NO_VACANT_ROOM"

def process_input(input_text):
    input_list = input_text.split()
    if len(input_list) < 3:
        return "INCORRECT_INPUT"

    command = input_list[0]
    if command == "VACANCY":
        start_time_str = input_list[1]
        end_time_str = input_list[2]
        if not is_valid_time_format(start_time_str) or not is_valid_time_format(end_time_str):
            return "INCORRECT_INPUT"

        start_time = datetime.strptime(start_time_str, '%H:%M').time()
        end_time = datetime.strptime(end_time_str, '%H:%M').time()

        available_rooms = get_available_rooms(start_time, end_time)
        return " ".join(available_rooms)

    elif command == "BOOK":
        if len(input_list) != 5:
            return "INCORRECT_INPUT"

        start_time_str = input_list[1]
        end_time_str = input_list[2]
        capacity_str = input_list[3]
        if not is_valid_time_format(start_time_str) or not is_valid_time_format(end_time_str):
            return "INCORRECT_INPUT"

        try:
            capacity = int(capacity_str)
        except ValueError:
            return "INCORRECT_INPUT"

        start_time = datetime.strptime(start_time_str, '%H:%M').time()
        end_time = datetime.strptime(end_time_str, '%H:%M').time()

        result = book_meeting_room(start_time, end_time, capacity)
        return result

    return "INCORRECT_INPUT"


sample_input = [
    "VACANCY 10:00 12:00",
    "BOOK 11:00 11:45 2",
    "BOOK 11:30 13:00 35",
    "BOOK 11:30 13:00 15",
    "VACANCY 11:30 12:00",
    "BOOK 14:00 15:30 3",
    "BOOK 15:00 16:30 2",
    "BOOK 15:15 12:15 12",
    "VACANCY 15:30 16:00",
    "BOOK 15:30 16:30 2",
    "VACANCY 15:45 16:00",
    "BOOK 16:00 17:00 5",
    "VACANCY 18:00 19:00"
]

for input_str in sample_input:
    output = process_input(input_str)
    print(output)
