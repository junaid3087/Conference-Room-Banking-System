from django.apps import AppConfig


class MeetingSchedulerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'meeting_scheduler'
