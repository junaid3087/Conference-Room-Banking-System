from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('meeting_scheduler/', include('meeting_scheduler.urls')),
]
